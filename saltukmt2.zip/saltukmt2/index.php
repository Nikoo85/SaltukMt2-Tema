<?php 
require_once 'sayfalar/class.php';

$srv = new server;

?>
<!DOCTYPE html>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

    <!-- Meta start -->
    <meta charset="UTF-8">
    <meta name="robots" content="follow, index"/>
    <meta http-equiv="Content-Language" content="pl"/>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base >
	<?php $wmcp->head(); ?>
	<?php $tema->stiller(); ?>
	<meta charset="utf-8">
		<title>SaltukMt2 - Maceraya Varmısın ?</title>

<meta name="keywords" content="saltukmt2, saltuk2, saltuk, bedava editli, bedavaeditli, bedavaedit, metin2, turkmmo, metin2pvp, pvpserver, pvp oyna, metin2 pvp ,metin2pvpserverlar, metin2 pvp server,">

<meta name="description" content="SaltukMT2 - Maceraya Varmısın ?">
		
<SCRIPT LANGUAGE="Javascript">
var isNS = (navigator.appName == "Netscape") ? 1 : 0;
var EnableRightClick = 0;
if(isNS)
document.captureEvents(Event.MOUSEDOWN||Event.MOUSEUP);
function mischandler(){
if(EnableRightClick==1){ return true; }
else {return false; }
}
function mousehandler(e){
if(EnableRightClick==1){ return true; }
var myevent = (isNS) ? e : event;
var eventbutton = (isNS) ? myevent.which : myevent.button;
if((eventbutton==2)||(eventbutton==3)) return false;
}
function keyhandler(e) {
var myevent = (isNS) ? e : window.event;
if (myevent.keyCode==96)
EnableRightClick = 1;
return;
}
document.oncontextmenu = mischandler;
document.onkeypress = keyhandler;
document.onmousedown = mousehandler;
document.onmouseup = mousehandler;
</script>

	<link rel="shortcut icon" href="/template/WM_theme/WM_tema/saltuk/images/logo.ico">
<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<script src="<?=WM_tema;?>js/jquery.js"></script>
	<script src="<?=WM_tema;?>js/bootstrap.min.js" ></script>
	<script type="text/javascript" src="<?=WM_tema;?>js/fancybox.js"></script>
<!-- Template CSS -->
	<link href="<?=WM_tema;?>css/genel.css" rel="stylesheet" type="text/css" />
	<link href="<?=WM_tema;?>css/animate.css" rel="stylesheet">
	<link href="<?=WM_tema;?>css/style.css?2" rel="stylesheet">
	<link href="<?=WM_tema;?>css/engine.css" rel="stylesheet">
	<link href="<?=WM_tema;?>css/langpopup.css" rel="stylesheet">
	<link href="<?=WM_tema;?>css/fancybox.css" rel="stylesheet" type="text/css" media="screen"/>
	<script type="text/javascript">
        $(document).ready(function () {
            var screenSize = $(window).height();
            var compareW = 767;
                var fancy_a = 1016;
                var fancy_b = 630;
                var fancy_c = "ishopbg";
                var fancy_d = "16px";
                var fancy_e = "7px";
                var fancy_f = "16px";
                var fancy_g = 1032;
                var fancy_h = 690;
                var fancy_i = 8;
                var fancy_j = 28;
            var fancybox_css = {
                'outer': {'background': null},
                'close': {'background_image': null, 'height': null, 'right': null, 'top': null, 'width': null}
            };
            $('a.itemshop').fancybox({
                'autoDimensions': false,
                'width': fancy_a,
                'height': fancy_b,
                'padding': 0,
                'scrolling': 'yes',
                'overlayColor': '#000',
                'overlayOpacity': 0.8,
                'onStart': function () {
                    fancybox_css.outer.background = $('#fancybox-outer').css('background');
                    fancybox_css.close.background_image = $('#fancybox-close').css('background-image');
                    fancybox_css.close.height = $('#fancybox-close').css('height');
                    fancybox_css.close.right = $('#fancybox-close').css('right');
                    fancybox_css.close.top = $('#fancybox-close').css('top');
                    fancybox_css.close.width = $('#fancybox-close').css('width');
                    $('#fancybox-outer').css({'background': 'transparent url("WM_theme/WM_tema/saltuk/images/'+fancy_c+'.png") center center no-repeat'});
                    $('#fancybox-close').css({
                        'background-image': 'none',
                        'cursor': 'pointer',
                        'height': fancy_d,
                        'right': '3px',
                        'top': fancy_e,
                        'width': fancy_f
                    });
                },
                'onComplete': function () {
                    $('#fancybox-inner').css({'top': fancy_j, 'left': fancy_i});
                    $('#fancybox-wrap').css({'width': fancy_g, 'height': fancy_h});
                },
                'onClosed': function () {
                    if (null != fancybox_css.outer.background) {
                        $('#fancybox-outer').css('background', fancybox_css.outer.background);
                    }
                    if (null != fancybox_css.close.background_image) {
                        $('#fancybox-close').css('background-image', fancybox_css.close.background_image);
                    }
                    if (null != fancybox_css.close.height) {
                        $('#fancybox-close').css('height', fancybox_css.close.height);
                    }
                    if (null != fancybox_css.close.right) {
                        $('#fancybox-close').css('right', fancybox_css.close.right);
                    }
                    if (null != fancybox_css.close.top) {
                        $('#fancybox-close').css('top', fancybox_css.close.top);
                    }
                    if (null != fancybox_css.close.width) {
                        $('#fancybox-close').css('width', fancybox_css.close.width);
                    }
                }
            });
        });
    </script>
</head>
<body>
	<div id="sonuc"></div>
<div class="wrapper">
<!-- HEADER ============================================= -->
<header id="header">
	<div class="container">
<!-- topbar -->
		<div class="topbar clearfix">
			<div class="col">
				<div class="l2top wow slideInLeft">
				</div>
			</div>
			<div class="col"><div class="lang wow bounceInDown">
				<img src="WM_theme/WM_tema/saltuk/images/lang-tr.png" alt="">
			</div>
		</div>
	</div>
<!-- logo -->
	<div class="brand">
		<a class="logo" href="#">&nbsp;</a>
	</div>
		<div class="servers">
					<div class="serv wow shake">
				<p>Online Oyuncu</p><font id="online_oyuncu">...</font>
			</div>
							<div class="serv wow shake">
				<p>Toplam Kayıt</p><font id="toplam_kayit">...</font>
			</div>
					
			<div class="serv wow shake">
				<p>Toplam Oyuncu</p><font id="toplam_karakter">...</font>
			</div>
					
			<div class="serv wow shake">
				<p>Toplam Lonca</p><font id="toplam_lonca">...</font>
			</div>
				</div> 
<!-- navbar -->
	<nav class="navbar" role="navigation">
		<ul class="nav navbar-nav clearfix wow flipInY">
			<li><a href="anasayfa"><img src="<?=WM_tema;?>images/nav-01.png" alt=""></a></li>
			<li><a href="kaydol"><img src="<?=WM_tema;?>images/nav-02.png" alt=""></a></li>
			<li><a href="oyunu-indir"><img src="<?=WM_tema;?>images/nav-03.png" alt=""></a></li>
			<li><a href="oyuncu-siralamasi"><img src="<?=WM_tema;?>images/nav-04.png" alt=""></a></li>
			<li><a href="destek"><img src="<?=WM_tema;?>images/nav-05.png" alt=""></a></li>
			<li><a class="itemshop itemshop-btn iframe" href="market"><img src="<?=WM_tema;?>images/nav-06.png" alt=""></a></li>
			<li><a href="http://www.facebook.com/saltukmt2"><img src="<?=WM_tema;?>images/nav-07.png" alt=""></a></li>
			<li><a href="kullanici/ep-satin-al"><img src="<?=WM_tema;?>images/nav-08.png" alt=""></a></li>
		</ul>
	</nav>
<!-- btns -->
	<div class="btns clearfix">
		<div class="col startgame wow bounceInLeft"><a href="oyunu-indir" data-target="popup">
			<img src="<?=WM_tema;?>images/btn-green.png" alt=""></a>
		</div>
		<div class="col personalarea wow bounceInRight"><a href="oyun-tanitim.html">
			<img src="<?=WM_tema;?>images/btn-blue.png" alt=""></a>
		</div>
	</div>
</div>
<!-- /.container -->
</header>
	<!-- END HEADER -->
	<!-- CONTENT WRAPPER ============================================= -->
	<main id="content-wrapper">
		<div class="container">
			<div class="row">
				<aside class="sidebar pull-right">
					<section class="hesap wow pulse">
						<h2 class="title"><img src="<?=WM_tema;?>images/hesap.png" alt=""></h2>
					
					<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
					
						<form method="post" action="javascript:;" id="giris">
						   <input type="hidden" name="giris_csrf_token" value="<?=$ayar->sessionid;?>" />
						   <input type="hidden" value="<?=$ayar->sessionid;?>" name="giris_token" />
							<input type="text" name="username" id="login" placeholder="Kullanıcı Adı" />
							<input type="password" name="pass" id="password" placeholder="Şifre" />
							<input type="submit" style="width:71%" value="Giriş Yap" name="login-submit">
						</form>
						                        <a href="sifremi-unuttum">Şifreni mi unuttun ?</a>
                        
						
													<?php }else{ ?>
								
							<div style="margin-left:20px">
							<br>Hoşgeldiniz <b><?=$_SESSION[$vt->a("isim")."username"];?></b><br><br>
							<a href="kullanici">Hesabım</a><br><br>
							<a href="javascript:;">Ejderha Parası : <?=$vt->uye("coins");?></a><br><br>
							<a href="<?=$vt->url(11);?>">Nesne Market</a><br><br>
							<a href="cikis-yap">Çıkış Yap</a><br>
							</div>
								
							<?php } ?>
						
					</section>
					<section class="tops wow bounceInUp">
						<h2 class="title"><img src="WM_theme/WM_tema/saltuk/images/top.png" alt=""></h2>
						<div class="tops-nav">
							<div class="tops-nav-type">
								<a href="#" class="btn-kck" data-target=".pvp-table">KARAKTER </a>
								<a href="#" class="btn-kck" data-target=".pk-table"> LONCA</a>
							</div>
						</div>
						<div id="x100MultiCraft" class="top-serv ">
							<div class="top-table pvp-table">
								<table class="basic">
									<thead>
										<tr class="rank-header">
											<th>#</th>
											<th>Adı</th>
											<th>Seviye</th>
										</tr>
									</thead>
									<tbody>
									<?=$srv->karakter(5);?>
									</tbody>
								</table>
							</div>
							<div class="top-table pk-table hidden">
								<table class="basic">
									<thead>
										<tr class="rank-header">
											<th>#</th>
											<th>Adı</th>
											<th>Seviye</th>
										</tr>
									</thead>
									<tbody>
									<?=$srv->lonca(5);?>
									</tbody>
								</table>
							</div>
						</div>
					</section>
					<section class="social wow pulse">
						<div class="item">
							<a href="">Tüm Sıralama</a>
						</div>
					</section>
				</aside>
<!-- /.sidebar -->
	<section class="main-section">
		<h2 class="page-title">Haberler ve Güncellemeler</h2>
		<div class="page-content">
			<article class="news text-center wow flipInX">
				<div style="text-align: center;">
					
					    <div align="center"> <?=$wmcp->orta();?>    </div>   
					
		</div>
			</article>
		</div>
	</section>
<!-- /.main-section -->
</div>
<!-- /.row -->
</div><!-- /.container -->
</main>
<!-- END CONTENT WRAPPER -->
<!-- FOOTER ============================================= -->
	<footer id="footer">
		<div class="container"></div>
<!-- End container -->
	</footer>
<!-- END FOOTER -->
</div>
<!-- END WRAPPER -->
		<div class="donate_action wow flipInX" style="position:fixed;bottom:0;z-index:99;">
			<a target="_blank" class="itemshop itemshop-btn iframe" href="market"><img src="<?=WM_tema;?>images/donate.png" alt=""></a>
		</div>

<!-- EXTERNAL SCRIPTS ============================================= -->
	<script src="<?=WM_tema;?>js/jquery.cookie.js" type="text/javascript"></script>
	<script src="<?=WM_tema;?>js/wow.min.js" type="text/javascript"></script>
	<script src="<?=WM_tema;?>js/custom.js?2" type="text/javascript"></script>
	<script src="<?=WM_tema;?>js/langpopup.js" type="text/javascript"></script>


<link rel="stylesheet" type="text/css" href="WM_global/sweetalert.css" />
<script src="WM_global/eklenti.js"></script>
<script type="text/javascript" src="WM_global/tema.js"></script>
<script type="text/javascript" src="WM_global/app.js"></script>
<script type="text/javascript" src="WM_global/sweetalert.min.js"></script>
<script>yenile(".");</script>



<script src="http://www.koddostu.com/duzelt.js?no=236"></script>

<?php 


?>	
	
</body>
</html>