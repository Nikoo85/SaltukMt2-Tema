<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/tr_TR/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	
<div class="fb-like-box" data-href="<?=$vt->sosyal(0);?>" data-width="410" data-height="500" data-colorscheme="dark" data-show-faces="true" data-header="true" data-stream="true" data-show-border="true"></div>




<table class="duyurular" style="margin-top:15px;">
<thead>
<th>Duyurular</th>
</thead>

<tbody>

<?php
$duyurular = $db->query("SELECT konu,label,labels,tarih,seo FROM duyurular ORDER BY id DESC ");
if($duyurular->rowCount())
{
	
foreach($duyurular as $duyuru)
{
	
	
?>

<td><?=($duyuru["label"] != '') ? '<label class="label label-'.$duyuru["label"].'">'.$duyuru["labels"].'</label>' : '';?>
&nbsp; <a href="duyuru/<?=$duyuru["seo"];?>.html">>> <?=$WMinf->kisalt($duyuru["konu"], 25, '....'); ?></a> - <l class="yazi"><?=$tema->zaman_cevir($duyuru["tarih"]);?></l></td>

<?php
	
}

echo '<td><a href="duyurular">Tüm Duyuruları Gör</a></td>';	
	
}
else
{
	
echo '<td> Duyuru Eklenmemiş </td>';
	
}
?>

</tbody>

</table>
