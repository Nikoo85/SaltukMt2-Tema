<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>




<div class="bg-dark">

                        <div class="col-50">
                            <a class="btn active" href="oyuncu-siralamasi">Oyuncu Sıralaması</a>
                        </div>
                        <div class="col-50">
                            <a class="btn" href="javascript:;">Lonca Sıralaması</a>
                        </div>
                    </div>
	
</table>
