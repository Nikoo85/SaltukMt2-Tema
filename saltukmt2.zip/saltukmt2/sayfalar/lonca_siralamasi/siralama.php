<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="bg-light ranking">
                        <table>
                            <tbody>
                            <tr>
                                <th>#</th>
                                <th>İsim</th>
                                <th>Seviye</th>
                                <th>Puan</th>
                                <th>Bayrak</th>
                                <th>Üye</th>
                                <th>Lider</th>
                            </tr>
							
	<?php 
	$i = $limit;
	foreach($query as $row){
		
	$uyeler = $odb->prepare("SELECT COUNT(guild_member.pid) AS COUNT FROM player.guild_member WHERE guild_id = ?");
	$uyeler->execute(array($row["id"]));
	$uyeler = $uyeler->fetchColumn();
		
	$i++;
	?>
	
	

	<tr>
                                <td><?=$i;?></td>
                                <td><a href="lonca/<?=$row["name"];?>"><?=$row["name"];?></a></td>
                                <td><?=$row["level"];?></td>
								<td><?=$row["ladder_point"];?></td>
                                <td><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.png"></td>
								<td><?=$uyeler;?></td>
								<td><a href="karakter/<?=$row["lider"];?>"><?=$row["lider"];?></a></td>
                            </tr>
	
    
	<?php 
	}
	?>
							
                  </tbody>
                        </table>
                    </div>

<div class="sayfalar">
<?php

$tema->sayfala("lonca-siralamasi?isim=$isim&sayfa=", $sayfa, $sayfada, $toplam_sayfa);

?>

</div>
