<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="bg-light download">
                        <table>
                            <tbody>
                            <tr>
                                <th><center>Dosya Adı</center></th>
                                <th><center>Açıklama</center></th>
                                <th><center>Boyutu</center></th>
                                <th><center>Link</center></th>
                            </tr>
							
							
  <?php 
  foreach($pack_sec as $pack){
  $linkler = explode(',' ,$pack["linkler"]);
  ?>
   <tr>
	<td><center><?=$pack["pack"];?></center></td>
	<td><center><?=$pack["aciklama"];?></center></td>
	<td><center><?=$pack["boyut"];?></center></td>
      <td><center>
	  <?php $i = 0; foreach($linkler as $link){ $i++;?>
	 <a href="<?=$link;?>" target="_blank">Link #<?=$i;?></a><br>
	  <?php } ?></center>
	  </td>
	</tr>
  
  
  <?php } ?>
							

                                                        </tbody>
                        </table>
                    </div>
					

					<div class="bg-light">
                        <h3>Sistem Gereksinimleri</h3>
                        <div class="col-50">
                            <strong>Minimum Özellikler</strong><br><br>
                            <strong>İşletim Sistemi:</strong> Windows Vista, 7<br>
                            <strong>CPU:</strong> Pentium 3 800MHz or higher<br>
                            <strong>RAM:</strong> 256MB<br>
                            <strong>VGA:</strong> 3D GeForce2 or ATI 9000<br>
                            <strong>HDD:</strong> 1,5 GB<br><br>
                        </div>
                        <div class="col-50">
                            <strong>Tavsiye Edilen Özellikler</strong><br><br>
                            <strong>İşletim Sistemi:</strong> Windows Vista, 7<br>
                            <strong>CPU:</strong> Pentium 4 2.4GHz or higher<br>
                            <strong>RAM:</strong> 512MB<br>
                            <strong>VGA:</strong> 3D GeForce FX 5600 or ATI9500<br>
                            <strong>HDD:</strong> 2 GB<br><br>
                        </div>
                    </div>