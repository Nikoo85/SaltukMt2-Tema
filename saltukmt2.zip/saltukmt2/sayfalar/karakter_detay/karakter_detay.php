<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="bg-light item-container">
                        <div class="player-card">
                            <h3>Karakter</h3>
                           <img class="img" src="<?=$ayar->WMimg.'profil/'.$fetch["job"];?>.png"> <br>
                            <span class="player-title"><i class="icon-power3 position-left"></i> <?=$fetch["level"];?> Level</span>
                        </div>
                        <div class="player-informations">
						
                            <h3>Detaylı Bilgi</h3>
							
							
                            <div class="player-table">
                                <div class="player-row">
                                    <strong><i class="icon-man position-left"></i> Karakter Adı:</strong>
                                    <span><?=$fetch["name"];?></span>
                                </div>

                                <div class="player-row">
                                    <strong><i class="icon-height position-left"></i> Beceri:</strong>
                                    <span><?=$tema->skill_group($fetch["job"], $fetch["skill_group"]);?></span>
                                </div>

                                <div class="player-row">
                                    <strong><i class="icon-flag4 position-left"></i> Bayrak:</strong>
                                    <span>Chunjo</span>
                                </div>
								
				<?php if($fetch["lonca"] != ""){?>
				
                                <div class="player-row">
                                    <strong><i class="icon-make-group position-left"></i> Lonca:</strong>
                                    <span><?=$fetch["lonca"];?></span>
                                </div>
				

				<?php } ?>


                                <div class="player-row">
                                    <strong><i class="icon-watch2 position-left"></i> Son Aktif Olma:</strong>
                                    <span>Yaklaşık <?=$tema->zaman_cevir($fetch["last_play"]);?></span>
                                </div>

                                <div class="player-row">
                                    <strong><i class="icon-watch position-left"></i> Oyun Süresi:</strong>
                                    <span><span title="<?=$fetch["playtime"];?>"><?=$fetch["playtime"];?> dakika.</span></span>
                                </div>
								
                                <div class="player-row">
                                    <strong><i class="icon-watch2 position-left"></i> Son Görüldüğü Yer:</strong>
                                    <span><?=$tema->konum($fetch["map_index"]);?></span>
                                </div>

                                <div class="player-row">
                                    <strong><i class="icon-feed position-left"></i> Durum:</strong>
                                    <span><?=$vt->online_kontrol($fetch["name"]);?></span>
                                </div>

                            </div>
							
											<div class="statsSec"> 
				 <div class="col"><span>VIT</span> <br><?=$fetch["ht"];?> </div> 
				 <div class="col"><span>INT</span> <br><?=$fetch["iq"];?>  </div> 
				 <div class="col"><span>STR</span> <br><?=$fetch["st"];?> </div> 
				 <div class="col"><span>DEX</span> <br><?=$fetch["dx"];?>  </div>
				</div>		

							
                        </div>
                        <div class="player-flag" style="background-color: rgba(84, 14, 14, 0.54);"></div>
                    </div>
					

