<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div style="margin-bottom:20px"></div>	
<h2>Oyuncu İmzası</h2><br>		
<hr>

<?php echo html_entity_decode($fetch["imza"]);?>

	<div style="clear:both;"></div>
