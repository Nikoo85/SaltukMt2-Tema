// JavaScript Document
$(document).ready(function(){


    $('.serv').each(function(){
        var perc = parseInt($(this).find('div:first').attr('data-percent'), 10);
        var dash = 300 + 183 / 100 * perc;
        $(this).find('svg:nth-child(2n)').attr('stroke-dashoffset', dash);
    });

    if (document.location.hash == "#eng") {
        if ($.cookie('lang') != "eng") {
            $.cookie('lang', "eng", {
                expires: 5,
                path: '/'
            });
            location.reload();
        }
    } else if (document.location.hash == "#rus") {
        if ($.cookie('lang') != "rus") {
            $.cookie('lang', "rus", {
                expires: 5,
                path: '/'
            });
            location.reload();
        }
    }
    if ($.cookie('lang') != null) {
        var lang = "#lg_" + $.cookie('lang');
        $(lang).addClass('active');
    }
    $('body').on('click', '[lg]', function () {
        $.cookie('lang', $(this).attr('lg'), {
            expires: 5,
            path: '/'
        });
        location.reload();
    });

  $('.tops-nav .tops-nav-serv a').click(function(e){
    $('.top-serv, .top-table').removeClass('active');
    var $target = $(this).attr('data-target');
    $('.tops-nav .tops-nav-serv a').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
    if(!$($target).is(':visible')) {
      $('.top-serv').stop().animate({opacity:0}, function(){
        $('.top-serv').hide();
        $($target).show().css({opacity:0}).stop().animate({opacity:1});
      });
    }
  });
  $('.tops-nav .tops-nav-type a').click(function(e){
    var $target = $(this).attr('data-target');
    $('.tops-nav .tops-nav-type a').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
    if(!$($target).is(':visible')) {
      $('.top-table').stop().animate({opacity:0}, function(){
        $('.top-table').hide();
        $($target).show().css({opacity:0}).stop().animate({opacity:1});
      });
    }
  });

  if ($(window).width() >= 960) {
    new WOW().init();
  }
});