function cookie(a, b) {
	if(b) document.cookie = a+'='+escape(b)+'; expires = Mon, 01-Jan-2999 00:00:00 GMT; path=/';
	var c = '(?:; )?'+a+'=([^;]*);?', d = new RegExp(c);
	return d.test(document.cookie) ? decodeURIComponent(RegExp['$1']) : 0;
}
$(document).ready(function(){
	if(!cookie('langview')) {
	}
  $('#popup .select-lang a').click(function(){
    cookie('langview', true);
  });
});